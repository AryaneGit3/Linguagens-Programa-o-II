
package modelo;

import java.util.ArrayList;
import java.util.List;

public class Dados {
    public static List<Endereco> listaEndereco = new ArrayList<>();
    public static List<Cliente> listaCliente = new ArrayList<>();
    public static List<Funcionario> listaFuncionario = new ArrayList<>();
    public static List<Fornecedor> listaFornecedor = new ArrayList<>();
    public static List<Produto> listaProduto = new ArrayList<>();
    public static List<Venda> listaVenda = new ArrayList<>();

}
